package exerAF.modelo;

public class Som {

	public Som() {
		System.out.println("Construiu Som");
	}
	
}
