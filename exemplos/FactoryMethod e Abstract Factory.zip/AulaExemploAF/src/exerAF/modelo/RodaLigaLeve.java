package exerAF.modelo;

public class RodaLigaLeve extends Roda{
	
	public RodaLigaLeve(){
		System.out.println("Construiu  RodaLigaLeve");
	}

}
