package modelo;


public class FabricaFord implements FabricaDeCarro {
	
	public FabricaFord() {}

	@Override
	public CarroSedan criarCarroSedan() {
		return new FiestaSedan();
	}

	@Override
	public CarroPopular criarCarroPopular() {
		return new Fiesta();
	}

}
