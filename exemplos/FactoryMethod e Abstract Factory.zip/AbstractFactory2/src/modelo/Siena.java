package modelo;

public class Siena implements CarroSedan {
	
	public Siena() {}

	@Override
	public String exibirInfoSedan() {
		return("Modelo: Siena\nFabrica: Fiat\nCategoria:Sedan");
	}

}
