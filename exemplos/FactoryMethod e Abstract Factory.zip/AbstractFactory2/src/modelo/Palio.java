package modelo;


public class Palio implements CarroPopular {

	public Palio() {}
	
	@Override
	public String exibirInfoPopular() {
		return("Modelo: Palio\nFabrica: Fiat\nCategoria:Popular");
	}

}
