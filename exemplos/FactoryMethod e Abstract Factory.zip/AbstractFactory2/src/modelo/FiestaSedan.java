package modelo;


public class FiestaSedan implements CarroSedan {
	
	public FiestaSedan() {}

	@Override
	public String exibirInfoSedan() {
		return("Modelo: Fiesta\nFabrica:Ford\nCategoria:Sedan");
	}

}
