package modelo;


public class Fiesta implements CarroPopular {
	
	public Fiesta() {}

	@Override
	public String exibirInfoPopular() {
		return("Modelo: Fiesta\nFabrica: Ford\nCategoria:Popular");
	}

}
