package modelo;


public class FabricaFiat implements FabricaDeCarro {
	
	public FabricaFiat() {}

	@Override
	public CarroSedan criarCarroSedan() {
		return new Siena();
	}

	@Override
	public CarroPopular criarCarroPopular() {
		return new Palio();
	}

}
