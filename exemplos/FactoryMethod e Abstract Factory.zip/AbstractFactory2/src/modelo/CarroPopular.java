package modelo;

public interface CarroPopular {
	public String exibirInfoPopular();
}
