package modelo;


public interface CarroSedan {
	public String exibirInfoSedan();
}
