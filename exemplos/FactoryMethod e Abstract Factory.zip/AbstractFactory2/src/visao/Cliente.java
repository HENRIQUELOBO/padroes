package visao;

import modelo.CarroPopular;
import modelo.CarroSedan;
import modelo.FabricaDeCarro;
import modelo.FabricaFiat;
import modelo.FabricaFord;

public class Cliente {
	public static void main(String[] args) {
		FabricaDeCarro fabrica = new FabricaFiat();
		CarroSedan sedan = fabrica.criarCarroSedan();
		CarroPopular popular = fabrica.criarCarroPopular();
		System.out.println(sedan.exibirInfoSedan());
		System.out.println();
		
		System.out.println(popular.exibirInfoPopular());
		System.out.println();

		fabrica = new FabricaFord();
		sedan = fabrica.criarCarroSedan();
		popular = fabrica.criarCarroPopular();
		System.out.println(sedan.exibirInfoSedan());
		System.out.println();
		System.out.println(popular.exibirInfoPopular());
	}
}
