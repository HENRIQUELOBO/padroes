package exemplo.modelo;

public class FabricaWolks implements FabricaDeCarro {
	
	public FabricaWolks() {}

	@Override
	public Carro criarCarro() {
		return new Gol();
	}

}
