package exemplo.modelo;

public class Celta implements Carro {
	
	public Celta() {}

	@Override
	public String exibirInfo() {
		return ("Modelo: Celta\nFabricante: Chevrolet");
	}

}
