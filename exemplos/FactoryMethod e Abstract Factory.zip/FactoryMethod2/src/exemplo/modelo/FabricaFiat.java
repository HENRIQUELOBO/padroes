package exemplo.modelo;

public class FabricaFiat implements FabricaDeCarro {
	
	public FabricaFiat() {}

	@Override
	public Carro criarCarro() {
		return new Palio();
	}

}
