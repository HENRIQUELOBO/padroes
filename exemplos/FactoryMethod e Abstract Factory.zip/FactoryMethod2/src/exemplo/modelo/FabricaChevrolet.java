package exemplo.modelo;

public class FabricaChevrolet implements FabricaDeCarro {
	
	public FabricaChevrolet() {}

	@Override
	public Carro criarCarro() {
		return new Celta();
	}

}
