package exemplo.modelo;

public class Fiesta implements Carro {
	
	public Fiesta() {}

	@Override
	public String exibirInfo() {
		return ("Modelo: Fiesta\nFabricante: Ford");
	}

}
