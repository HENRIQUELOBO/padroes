package exemplo.modelo;

public interface Carro {
	public String exibirInfo();
}
