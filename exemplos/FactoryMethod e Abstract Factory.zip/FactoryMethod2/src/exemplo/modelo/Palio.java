package exemplo.modelo;

public class Palio implements Carro {
	
	public Palio() {}

	@Override
	public String exibirInfo() {
		return ("Modelo: Palio\nFabricante: Fiat");
	}

}
