package exemplo.modelo;

public class FabricaFord implements FabricaDeCarro {
	
	public FabricaFord() {
	}

	@Override
	public Carro criarCarro() {
		return new Fiesta();
	}

}
