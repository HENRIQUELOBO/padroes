package exemplo.modelo;

public interface FabricaDeCarro {
	public Carro criarCarro();
}
