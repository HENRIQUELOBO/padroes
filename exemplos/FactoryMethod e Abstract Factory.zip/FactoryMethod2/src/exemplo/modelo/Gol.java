package exemplo.modelo;

public class Gol implements Carro {
	
	public Gol() {}

	@Override
	public String exibirInfo() {
		return ("Modelo: Gol\nFabricante: Volkswagen");
	}

}
