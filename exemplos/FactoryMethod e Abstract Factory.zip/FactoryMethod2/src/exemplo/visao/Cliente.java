package exemplo.visao;

import exemplo.modelo.Carro;
import exemplo.modelo.FabricaChevrolet;
import exemplo.modelo.FabricaDeCarro;
import exemplo.modelo.FabricaFord;
import exemplo.modelo.FabricaWolks;

public class Cliente {
	public static void main(String[] args) {
		FabricaDeCarro fabrica = new FabricaChevrolet();
		Carro carro = fabrica.criarCarro();
		System.out.println(carro.exibirInfo());
		System.out.println();

		fabrica = new FabricaWolks();
		carro = fabrica.criarCarro();
		System.out.println(carro.exibirInfo());
		System.out.println();

		fabrica = new FabricaFord();
		carro = fabrica.criarCarro();
		System.out.println(carro.exibirInfo());
		System.out.println();

		fabrica = new FabricaChevrolet();
		carro = fabrica.criarCarro();
		System.out.println(carro.exibirInfo());
	}
}
