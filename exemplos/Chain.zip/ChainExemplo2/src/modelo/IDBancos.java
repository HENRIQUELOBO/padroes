package modelo;

public enum IDBancos {
	bancoA, bancoB, bancoC, bancoD 
}
