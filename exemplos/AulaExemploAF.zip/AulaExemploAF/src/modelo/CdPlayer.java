package modelo;

public class CdPlayer extends Som{

	public CdPlayer(){
		System.out.println("CdPlayer");
	}

}
