package modelo;

public class RodaLigaLeve extends Roda{
	
	public RodaLigaLeve(){
		System.out.println("RodaLigaLeve");
	}

}
