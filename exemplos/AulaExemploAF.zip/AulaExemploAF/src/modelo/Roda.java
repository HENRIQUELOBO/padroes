package modelo;

public class Roda {

}
