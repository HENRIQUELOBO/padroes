package modelo;

public class Paredao extends Som{

	public Paredao(){
		System.out.println("Paredao");
	}
}
