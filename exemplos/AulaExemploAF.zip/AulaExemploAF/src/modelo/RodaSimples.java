package modelo;

public class RodaSimples extends Roda{

	public RodaSimples(){
		System.out.println("RodaSimples");
	}
}
