package model;

public interface PagamentoCommand {
	void processarCompra(Compra compra);
}
