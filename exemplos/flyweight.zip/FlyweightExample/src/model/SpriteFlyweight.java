package model;
public abstract class SpriteFlyweight {
    public abstract void desenharImagem(Ponto ponto);
    
}