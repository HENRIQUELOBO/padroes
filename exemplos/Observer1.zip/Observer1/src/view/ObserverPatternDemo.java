package view;

import model.designPatterns.BinaryObserver;
import model.designPatterns.HexaObserver;
import model.designPatterns.Observer;
import model.designPatterns.OctalObserver;
import model.designPatterns.Subject;

public class ObserverPatternDemo {
	public static void main(String[] args) {
		Subject subject = new Subject();

		Observer ob1 = new HexaObserver(subject);
		Observer ob2 = new OctalObserver(subject);
		Observer ob3 = new BinaryObserver(subject);

		System.out.println("Primeiro valor (estado)= 15");	
		subject.setState(15);
		System.out.println("\nSegundo valor (estado)= 10");	
		subject.setState(10);
		
		//subject.notifyAllObservers();
	}
}
