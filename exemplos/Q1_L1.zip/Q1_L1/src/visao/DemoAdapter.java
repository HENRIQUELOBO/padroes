package visao;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import model.AdapterMap;

public class DemoAdapter {
	
	public static void listar(Map m) {
		Set chaves = m.keySet();
		for (Object chave : chaves){
			if(chave != null)
				System.out.println(chave + " - "+ m.get(chave));
		}
	}
	
	
	public static void main(String args[]) {
		
		Map m = new HashMap<String, String>();
		m.put("chave 1", "valor 1");
		m.put("chave 2", "valor 2");
		m.put("chave 4", "valor 3");
		listar(m);
		
		
		List lista = Arrays.asList("Alana", "Marques", "Morais");
		Map m2 = new AdapterMap(lista);
		listar(m2);
		
		
		
	}

}
