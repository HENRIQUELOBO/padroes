module Q1_L1 {
}