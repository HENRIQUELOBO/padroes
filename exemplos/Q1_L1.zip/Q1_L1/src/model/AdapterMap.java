package model;
import java.util.HashMap;
import java.util.List;


public class AdapterMap extends HashMap{

	private List listaMap;
	
	
	public AdapterMap(List lista) {
		this.listaMap = lista;
		carregarDados();
	}
	
	public void carregarDados() {
		for (int i = 0; i<listaMap.size(); i++) {
			put(i, listaMap.get(i));
		}
	}

	public List getListaMap() {
		return listaMap;
	}

	public void setListaMap(List listaMap) {
		this.listaMap = listaMap;
	}
	
	
	

}
