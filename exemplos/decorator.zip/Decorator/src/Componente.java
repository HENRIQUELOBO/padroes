public interface Componente {
	Object getDados();

	void operacao(Object arg);
}