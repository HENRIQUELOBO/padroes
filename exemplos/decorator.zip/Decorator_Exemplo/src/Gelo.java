
public class Gelo extends CoquetelDecorator{
	public Gelo(Coquetel umCoquetel) {
        super(umCoquetel);
        nome = "Gelo";
        preco = 0.5;
    }
}
