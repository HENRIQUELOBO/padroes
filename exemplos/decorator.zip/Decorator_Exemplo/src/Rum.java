
public class Rum extends Coquetel{
	public Rum(){
		nome = "Rum";
		preco = 3;
	}

}
