public class Caipirinha extends Coquetel {
    public Caipirinha() {
        nome = "Caipirinha";
        preco = 3.5;
    }
}