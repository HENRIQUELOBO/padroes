
public class Vodka extends Coquetel{
	public Vodka(){
		nome = "Vodka";
		preco = 5;
	}
}
