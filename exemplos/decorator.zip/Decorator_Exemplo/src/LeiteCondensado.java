
public class LeiteCondensado extends CoquetelDecorator {
	public LeiteCondensado(Coquetel umCoquetel) {
        super(umCoquetel);
        nome = "LeiteCondensado";
        preco = 2.0;
    }
}
