package model;
public class JanelaDialogo extends Janela {
	
	public JanelaDialogo(JanelaImplementada j) {
		super(j);
	}

	public void desenhar() {
		System.out.println(desenharJanela("Janela de Diálogo"));
		System.out.println(desenharBotao("Botão Sim"));
		System.out.println(desenharBotao("Botão Não"));
		System.out.println(desenharBotao("Botão Cancelar \n"));
	}
}
