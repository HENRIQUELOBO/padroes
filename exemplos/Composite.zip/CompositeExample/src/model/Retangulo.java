package model;

public class Retangulo extends Grafico{
	
	public Retangulo() {
		super();
	}

	public void desenhar() {
		System.out.println("Desenha Retangulo");
		
	}

	
}
