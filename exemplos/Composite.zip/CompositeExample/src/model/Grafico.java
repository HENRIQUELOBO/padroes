package model;

public class Grafico {
	
	public Grafico() {}
	
	public void desenhar(){}
	public void adicionarF(Grafico g){}
	public void remover(int i){}
	
}
