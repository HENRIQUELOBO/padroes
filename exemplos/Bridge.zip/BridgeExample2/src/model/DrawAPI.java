package model;

public interface DrawAPI {
	
	public String drawCircle(int radius, int x, int y);
}
