package model;

public interface JanelaImplementada {

	public String desenharJanela(String titulo);
	 
    public String desenharBotao(String titulo);
	
}
