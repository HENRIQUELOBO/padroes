package iteratorExterno;

public interface AgregadoDeCanais {
	IteradorInterface criarIterator();
}