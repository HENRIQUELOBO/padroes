package model;

public class Loja {
	protected String nomeDaLoja;
	//PagamentoCommand veio como parametro 

	public Loja(String nome) {
		nomeDaLoja = nome;
	}

	public void executarCompra(double valor, PagamentoCommand formaDePagamento) {
		Compra compra = new Compra(nomeDaLoja);
		compra.setValor(valor);
		formaDePagamento.processarCompra(compra);
	}
}
