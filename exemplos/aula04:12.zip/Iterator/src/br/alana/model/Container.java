package br.alana.model;
public interface Container {
	
   public Iterator getIterator();
}