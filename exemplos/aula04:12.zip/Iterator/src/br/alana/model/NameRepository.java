package br.alana.model;
public class NameRepository implements Container {
	
	private String names[] = {"Robert" , "John" ,"Julie" , "Lora"};

	public Iterator getIterator() {
		return new NameIterator();
	}

	public String[] getNames() {
		return names;
	}

	public void setNames(String names[]) {
		this.names = names;
	}
	
	

	
}