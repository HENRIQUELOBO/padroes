package br.alana.model;

public class NameIterator implements Iterator{
	
	int index;
	NameRepository nRep = new NameRepository();
	
	public boolean hasNext() {
		if(index < nRep.getNames().length){
			return true;
		}
		return false;
	}

	public Object next() {
		if(this.hasNext()){
			return nRep.getNames()[index++];
		}
		return null;
	}

}