package br.alana.model;
public interface Iterator {
	
   public boolean hasNext();
   public Object next();
}