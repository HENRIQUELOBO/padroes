package iteratorExterno;

public class IteradorMatrizDeCanais implements IteradorInterface {
	protected Canal[] lista;
	protected int contador;

	public IteradorMatrizDeCanais(Canal[] lista) {
		this.lista = lista;
	}

	public void first() {
		contador = 0;
	}

	public void next() {
		contador++;
	}

	public boolean isDone() {
		return contador == lista.length;
	}

	public Canal currentItem() {
		if (isDone()) {
			contador = lista.length - 1;
		} else if (contador < 0) {
			contador = 0;
		}
		return lista[contador];
	}
}
