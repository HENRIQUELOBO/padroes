package iterator;

public class Canal {
	String nome;

	public Canal(String nome) {
		this.nome = nome;
	}
}
